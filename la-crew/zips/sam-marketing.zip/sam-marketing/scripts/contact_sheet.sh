#!/bin/bash
# Usage: contact_sheet.sh <short_name> <download_url> <work_dir>
# Downloads one video, writes durations.tsv + sheets/<name>.jpg (6 frames), then deletes the video.
# Run many in parallel: cat batch.txt | xargs -P 6 -n 2 ./contact_sheet.sh   (with W exported)
n="$1"; url="$2"; W="${3:-$W}"; mkdir -p "$W/sheets"
f="$W/$n.vid"
curl -sS -o "$f" "$url" || exit 1
d=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$f")
echo -e "$n\t$d" >> "$W/durations.tsv"
FONT=$(fc-list | grep -m1 -E "Inter-Bold|DejaVuSans-Bold" | cut -d: -f1)
args=()
for i in 0 1 2 3 4 5; do
  t=$(python3 -c "print(round($d*($i+0.5)/6,2))")
  ffmpeg -v error -y -ss "$t" -i "$f" -frames:v 1 -vf "scale=-2:300" "$W/${n}_$i.jpg" && args+=(-i "$W/${n}_$i.jpg")
done
[ ${#args[@]} -eq 12 ] && ffmpeg -v error -y "${args[@]}" -filter_complex "hstack=6,pad=iw:ih+40:0:40:white,drawtext=fontfile=$FONT:text='$n  ${d%.*}s':x=10:y=8:fontsize=26" "$W/sheets/$n.jpg"
rm -f "$f" "$W/${n}"_?.jpg
