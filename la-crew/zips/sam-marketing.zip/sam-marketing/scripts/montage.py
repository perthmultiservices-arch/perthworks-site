#!/usr/bin/env python3
"""Vertical 1080x1920 short-video builder (TikTok / Reels / Shorts).

Usage: python3 montage.py plan.json
plan.json example:
{
  "out": "tiktok_fence.mp4",
  "brand": {"phone": "0400 000 000", "cta": "FREE QUOTES", "box_colour": "F5C400"},
  "clips": [
    {"src": "after.mov", "ss": 0.6, "dur": 1.6,
     "texts": [{"t": "This fence was", "style": "white", "y": 330, "size": 74},
               {"t": "GREY", "style": "box", "y": 450, "size": 96}]},
    {"src": "before.jpg", "dur": 1.7, "zoom": "in", "texts": [{"t": "BEFORE", "style": "box"}]},
    {"src": "sanding.mov", "ss": 4.5, "dur": 4.0, "speed": 2.0, "keep_audio": true,
     "texts": [{"t": "SAND IT BACK", "style": "box"}]},
    {"src": "rail.mov", "ss": 0.3, "dur": 2.1, "crop_top": 0.62, "texts": []},
    {"src": "after.mov", "ss": 3.8, "dur": 3.2, "end_card": "Fence restoration, Northside"}
  ],
  "transitions": ["fadewhite", "fade", "wipeleft", "fadewhite"]
}
- src: video (.mov/.mp4) or photo (.jpg/.png). Photos get a slow Ken Burns zoom ("in"/"out"/"punch").
- texts: style "box" = black text on yellow box (labels), "white" = white text with black outline.
  Default y=330 (top safe zone). Keep text out of the bottom 400 px and the right 150 px (TikTok buttons).
  "from": seconds into the clip before the text appears (use it when a wipe would mix two labels).
- keep_audio: keep that clip's own sound (sander, pressure washer, spray gun). Other clips are muted.
- end_card: adds the closing card (title at top, brand.cta in a box + brand.phone mid-screen).
- brand (optional, top level): phone, cta, box_colour (hex, no #). Phone can be a website instead.
- transitions: one per gap (len = clips-1). xfade names: fade, fadewhite, wipeleft, slideleft, smoothleft.
A soft "whoosh" is added on every transition.
"""
import json, subprocess as sp, sys, os, glob, tempfile

FONT = next((p for p in ["/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf",
                         "/usr/share/fonts/opentype/inter/Inter-Bold.otf"] if os.path.exists(p)),
            None) or sp.run("fc-list | grep -m1 -i 'bold' | cut -d: -f1", shell=True,
                            capture_output=True, text=True).stdout.strip()
WHITE = f"fontfile={FONT}:fontcolor=white:borderw=7:bordercolor=black:x=(w-text_w)/2"
BOX = f"fontfile={FONT}:fontcolor=black:box=1:boxcolor=0xF5C400:boxborderw=24:x=(w-text_w)/2"
PHONE, CTA = "", "FREE QUOTES"
TRANS_DUR = {"fade": 0.2, "fadewhite": 0.2, "wipeleft": 0.5, "slideleft": 0.25, "smoothleft": 0.3}


def run(c):
    sp.run(c, shell=True, check=True)


def esc(t):
    return t.replace("\\", "\\\\").replace(":", "\\:").replace("'", "’").replace(",", "\\,")


def text_filters(clip):
    out = []
    for x in clip.get("texts", []):
        st = BOX if x.get("style", "box") == "box" else WHITE
        size = x.get("size", 84 if x.get("style", "box") == "box" else 68)
        en = f":enable='gte(t\\,{x['from']})'" if "from" in x else ""
        out.append(f"drawtext={st}:fontsize={size}:y={x.get('y', 330)}:text='{esc(x['t'])}'{en}")
    if clip.get("end_card"):
        out += [f"drawtext={WHITE}:fontsize=66:y=330:text='{esc(clip['end_card'])}'",
                f"drawtext={BOX}:fontsize=74:y=980:text='{esc(CTA)}'"]
        if PHONE:
            out.append(f"drawtext={WHITE}:fontsize=88:y=1110:text='{esc(PHONE)}'")
    return ",".join(out)


def build_clip(c, out, tmp):
    n = int(round(c["dur"] * 30))
    txt = text_filters(c)
    is_img = os.path.splitext(c["src"])[1].lower() in (".jpg", ".jpeg", ".png", ".heic")
    if is_img:
        z = {"in": "1.0+0.0015*on", "out": "1.12-0.0015*on",
             "punch": "if(lt(on,8),1.35-0.04375*on,1.0+0.001*(on-8))"}[c.get("zoom", "in")]
        vf = (f"scale=2160:3840:force_original_aspect_ratio=increase,crop=2160:3840,"
              f"zoompan=z='{z}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=1080x1920:fps=30"
              + (f",{txt}" if txt else "") + ",format=yuv420p")
        run(f'ffmpeg -v error -y -loop 1 -i "{c["src"]}" -vf "{vf}" -frames:v {n} -an '
            f'-c:v libx264 -crf 18 -preset fast "{out}"')
        return False
    sp_ = c.get("speed", 1.0)
    pre = f"crop=iw:ih*{c['crop_top']}:0:0," if "crop_top" in c else ""
    vf = (pre + "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
          + (f",setpts=PTS/{sp_}" if sp_ != 1 else "") + ",fps=30"
          + (f",{txt}" if txt else "") + ",format=yuv420p")
    keep = c.get("keep_audio", False)
    a = (f"-af atempo={min(sp_, 2.0)}" + (f",atempo={sp_/2}" if sp_ > 2 else "")
         + " -c:a aac -ar 44100 -ac 2") if keep else "-an"
    run(f'ffmpeg -v error -y -ss {c.get("ss", 0)} -t {c["dur"]*sp_+0.5} -i "{c["src"]}" '
        f'-vf "{vf}" -frames:v {n} {a} -c:v libx264 -crf 18 -preset fast "{out}"')
    return keep


def main(plan_path):
    global PHONE, CTA, BOX
    plan = json.load(open(plan_path))
    b = plan.get("brand", {})
    PHONE, CTA = b.get("phone", PHONE), b.get("cta", CTA)
    if b.get("box_colour"):
        BOX = BOX.replace("0xF5C400", "0x" + b["box_colour"].lstrip("#"))
    clips, trans = plan["clips"], plan.get("transitions") or ["fade"] * (len(plan["clips"]) - 1)
    tmp = tempfile.mkdtemp(dir=os.path.dirname(os.path.abspath(plan_path)))
    files, keeps = [], []
    for i, c in enumerate(clips):
        f = os.path.join(tmp, f"c{i}.mp4")
        keeps.append(build_clip(c, f, tmp)); files.append(f)
    fc, prev, t, times = [], "[0:v]", clips[0]["dur"], []
    starts = [0.0]
    for i, tr in enumerate(trans):
        d = TRANS_DUR.get(tr, 0.25); off = t - d; times.append(off); starts.append(off)
        fc.append(f"{prev}[{i+1}:v]xfade=transition={tr}:duration={d}:offset={off:.3f}[v{i}]")
        prev = f"[v{i}]"; t = off + clips[i + 1]["dur"]
    total = t
    amix = []
    for k, off in enumerate(times):
        ms = int(off * 1000)
        fc.append(f"anoisesrc=d=0.45:c=pink:a=0.5,highpass=f=700,lowpass=f=5000,afade=t=in:d=0.2,"
                  f"afade=t=out:st=0.2:d=0.25,volume=0.3,adelay={ms}|{ms}[w{k}]"); amix.append(f"[w{k}]")
    for i, k in enumerate(keeps):
        if k:
            ms, d = int(starts[i] * 1000), clips[i]["dur"]
            fc.append(f"[{i}:a]afade=t=in:d=0.1,afade=t=out:st={max(d-0.4,0)}:d=0.4,volume=0.8,"
                      f"adelay={ms}|{ms}[s{i}]"); amix.append(f"[s{i}]")
    if not amix:
        fc.append(f"anullsrc=r=44100:cl=stereo,atrim=0:{total:.3f}[a]")
    else:
        fc.append("".join(amix) + f"amix=inputs={len(amix)}:normalize=0,apad,atrim=0:{total:.3f},"
                  "aformat=channel_layouts=stereo[a]")
    inputs = " ".join(f'-i "{f}"' for f in files)
    out = plan.get("out", "short_video.mp4")
    run(f'ffmpeg -v error -y {inputs} -filter_complex "{";".join(fc)}" -map {prev} -map "[a]" '
        f'-c:v libx264 -crf 19 -preset medium -pix_fmt yuv420p -c:a aac -b:a 128k -ar 44100 '
        f'-movflags +faststart "{out}"')
    # preview strip for visual QA
    strip = os.path.splitext(out)[0] + "_preview.jpg"
    pts = [round(total * (i + 0.5) / 8, 2) for i in range(8)]
    imgs = []
    for i, p in enumerate(pts):
        im = os.path.join(tmp, f"p{i}.jpg")
        run(f'ffmpeg -v error -y -ss {p} -i "{out}" -frames:v 1 -vf scale=-2:420 "{im}"'); imgs.append(im)
    run("ffmpeg -v error -y " + " ".join(f'-i "{x}"' for x in imgs) + f' -filter_complex hstack=8 "{strip}"')
    for f in glob.glob(os.path.join(tmp, "*")): os.remove(f)
    os.rmdir(tmp)
    print(f"OK {out} {total:.1f}s  preview: {strip}")


if __name__ == "__main__":
    main(sys.argv[1])
