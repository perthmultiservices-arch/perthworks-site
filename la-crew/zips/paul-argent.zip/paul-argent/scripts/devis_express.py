#!/usr/bin/env python3
"""Quick quote engine (Paul Express / Devis express). Exact maths + PDF(s) in one run (< 1 s).

Usage: python3 devis_express.py job.json [out_dir]
Prints a JSON summary: totals, range, maths line, warnings, to_check, files.

job.json — only business, client and items are required:
{
 "langs": ["en"] | ["fr"] | ["en","fr"],      # several = one PDF per language (2nd+ marked internal if "internal": true)
 "internal": true,                             # non-first languages = owner's internal copy (shows the maths)
 "country": "FR"|"AU"|"UK"|"US"|"CA"|"NZ"|"IE"|..., "currency": "€"|"$"|"£",
 "draft": false,                               # true = stamps DRAFT / À CONFIRMER
 "business": {"name","legal","id_label","id","address","phone","email","web","insurance","bank","colour":"#13232B","accent":"#FFC629","logo":"logo.png"},
 "client": {"name","address","id"},
 "number": "D-0012", "date": "2026-10-04", "validity_days": 30, "start": "...", "duration": "...",
 "title": "text or {\"en\":..,\"fr\":..}",
 "pricing": {"labour_rate": 100, "hours_per_day": 8, "materials_markup": 0.20, "travel": 60, "travel_label": "...",
             "min_total": 0, "labour_floor": 100, "tax_rate": 0.10, "tax_registered": true, "tax_label": "GST",
             "show": "lines" | "total", "round_to": 0, "range_pct": 0.15, "ceiling_height": 2.4,
             "grid": {"code": {"desc": "...", "unit": "m²", "price": 18}} | "prices.json"},
 "rooms": [{"name":"Bedroom","L":4,"W":3.5,"H":2.4,"openings":3,"walls":"wall_paint","ceiling":"ceiling_paint"}],
 "items": [
   {"desc":"...","qty":42,"unit":"m²","price":18},          # unit price excl. tax
   {"code":"wall_paint","qty":42},                          # price from the grid
   {"desc":"Labour","hours":6,"people":2},                  # labour (rate = pricing.labour_rate unless "rate")
   {"desc":"Labour","days":1,"people":2},                   # days × hours_per_day
   {"desc":"Paint and filler","materials":150}               # cost; markup applied
 ],
 "scope": ["what is done, plain words"], "excluded": ["..."], "notes": ["..."],
 "deposit_pct": 0.30, "payment": "...", "warranty": "...", "variation_clause": "...", "accept": "...", "file": "Quote_X_Name"
}
Any text field may be a string or {"en": "...", "fr": "..."}.
"""
import sys, json, os, math, datetime, subprocess
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_RIGHT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

FN, FB = "Helvetica", "Helvetica-Bold"
for reg_, bold_ in (("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"),
                    ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")):
    if os.path.exists(reg_) and os.path.exists(bold_):
        pdfmetrics.registerFont(TTFont("QF", reg_)); pdfmetrics.registerFont(TTFont("QF-B", bold_))
        pdfmetrics.registerFontFamily("QF", normal="QF", bold="QF-B", italic="QF", boldItalic="QF-B"); FN, FB = "QF", "QF-B"; break
SQ = "m²" if FN != "Helvetica" else "m2"

J = json.load(open(sys.argv[1])); OUT = sys.argv[2] if len(sys.argv) > 2 else "."
os.makedirs(OUT, exist_ok=True)
LANGS = J.get("langs") or [J.get("lang", "fr")]
C = J.get("country", "FR").upper(); CUR = J.get("currency", "€" if C == "FR" else ("£" if C == "UK" else "$"))
P = J.get("pricing", {}); B = J["business"]; CL = J["client"]
TX = {
 "fr": dict(quote="DEVIS", no="N°", date="Date", valid="Valable jusqu'au", client="Client", desc="Désignation", qty="Qté", unit="Unité",
            pu="P.U. HT", amount="Montant HT", sub="Total HT", tax="TVA", total="Total TTC", total_nt="Total", deposit="Acompte à la signature",
            balance="Solde à la fin des travaux", start="Début prévu", duration="Durée estimée", excluded="Non compris", notes="Conditions",
            labour="Main-d'œuvre", materials="Fournitures", travel="Déplacement", mintot="Minimum d'intervention", h="h", scope="Travaux",
            accept="Bon pour accord — date et signature du client :", notax="TVA non applicable, art. L. 223-3 du CIBS", walls="murs", ceiling="plafond",
            discount="Remise", page="Page", internal="COPIE INTERNE — ne pas envoyer au client", maths="Calcul", draft="BROUILLON — À CONFIRMER", colon=" :"),
 "en": dict(quote="QUOTE", no="No.", date="Date", valid="Valid until", client="Client", desc="Description", qty="Qty", unit="Unit",
            pu="Unit price", amount="Amount", sub="Subtotal (excl. tax)", tax="GST", total="Total (incl. tax)", total_nt="Total", deposit="Deposit on acceptance",
            balance="Balance on completion", start="Planned start", duration="Estimated duration", excluded="Not included", notes="Terms",
            labour="Labour", materials="Materials", travel="Travel", mintot="Minimum charge", h="hrs", scope="Scope of works",
            accept="To accept, reply YES or sign and date below:", notax="No GST charged (not registered for GST)", walls="walls", ceiling="ceiling",
            discount="Discount", page="Page", internal="INTERNAL COPY — do not send to the client", maths="Maths", draft="DRAFT — TO CONFIRM", colon=":"),
}
def labels(L):
    T = dict(TX[L])
    if L == "en" and C in ("UK", "IE"): T["tax"] = "VAT"; T["notax"] = "No VAT charged (not VAT-registered)"
    if L == "en" and C == "US": T["tax"] = "Sales tax"
    if L == "fr" and C != "FR":
        tl = P.get("tax_label", "GST" if C in ("AU", "NZ", "CA") else "taxe")
        T.update(tax=tl, sub=f"Total hors {tl}", total=f"Total {tl} comprise", pu="P.U. hors taxe", amount="Montant hors taxe", notax="Pas de taxe facturée")
    if P.get("tax_label") and L == "en": T["tax"] = P["tax_label"]
    return T
def tr_(v, L):
    if isinstance(v, dict): return v.get(L) or next(iter(v.values()))
    return v
def money(x, L):
    s = f"{x:,.2f}"
    if L == "fr": return s.replace(",", " ").replace(".", ",") + " " + CUR
    return ("-" if x < 0 else "") + CUR + s.lstrip("-")
def num(x, L):
    s = f"{x:g}" if abs(x - round(x)) < 1e-9 else f"{x:.2f}"
    return s.replace(".", ",") if L == "fr" else s

# ---------- compute (language-independent) ----------
warn, to_check = [], []
grid = P.get("grid", {})
if isinstance(grid, str): grid = json.load(open(grid))
hpd = P.get("hours_per_day", 8); dflt_h = P.get("ceiling_height", 2.5 if C == "FR" else 2.4)
lines = []   # dict(desc={L:..}|str, qty, unit, pu, amt)
maths_parts = []  # functions L -> str
for r in J.get("rooms", []):
    Lr, Wr, Hr = r["L"], r["W"], r.get("H", dflt_h)
    if "H" not in r: to_check.append(f"height {Hr} m assumed ({tr_(r['name'], 'en')})")
    walls = round(2 * (Lr + Wr) * Hr - r.get("openings", 0), 2); ceil = round(Lr * Wr, 2)
    maths_parts.append(lambda L, r=r, Lr=Lr, Wr=Wr, Hr=Hr, walls=walls, ceil=ceil:
                       f"{tr_(r['name'], L)}: {TX[L]['walls']} 2×({num(Lr, L)}+{num(Wr, L)})×{num(Hr, L)}−{num(r.get('openings', 0), L)} = {num(walls, L)} {SQ}, {TX[L]['ceiling']} {num(ceil, L)} {SQ}")
    for part, area in (("walls", walls), ("ceiling", ceil)):
        code = r.get(part)
        if not code: continue
        g = grid.get(code)
        if not g: warn.append(f"price grid code '{code}' missing — ask the owner"); continue
        lines.append(dict(desc={L: f"{tr_(g['desc'], L)} — {tr_(r['name'], L)}" for L in ("en", "fr")}, qty=area, unit=g.get("unit", SQ), pu=g["price"], amt=area * g["price"]))
labour_total = labour_hours = 0.0
for it in J["items"]:
    if "code" in it:
        g = grid.get(it["code"])
        if not g: warn.append(f"price grid code '{it['code']}' missing — ask the owner"); continue
        q = it.get("qty", 1); pu = it.get("price", g["price"])
        lines.append(dict(desc=it.get("desc", g["desc"]), qty=q, unit=it.get("unit", g.get("unit", "")), pu=pu, amt=q * pu))
    elif "hours" in it or "days" in it:
        ppl = it.get("people", 1); rate = it.get("rate", P.get("labour_rate"))
        if rate is None: warn.append("no labour rate — ask the owner"); continue
        hrs = it["hours"] if "hours" in it else it["days"] * hpd
        if "days" in it and "hours" not in it: to_check.append(f"{num(it['days'], 'en')} day(s) = {num(hrs, 'en')} h per person")
        ph = hrs * ppl; amt = ph * rate; labour_total += amt; labour_hours += ph
        lines.append(dict(desc=it.get("desc", {"en": TX["en"]["labour"], "fr": TX["fr"]["labour"]}), qty=hrs, unit={L: TX[L]["h"] + (f" × {ppl}" if ppl > 1 else "") for L in ("en", "fr")}, pu=rate * ppl, amt=amt))
        maths_parts.append(lambda L, hrs=hrs, ppl=ppl, rate=rate, amt=amt: f"{TX[L]['labour']} {num(hrs, L)} {TX[L]['h']} × {ppl} × {money(rate, L)} = {money(amt, L)}")
    elif "materials" in it:
        mk = it.get("markup", P.get("materials_markup", 0)); cost = it["materials"]; amt = cost * (1 + mk)
        lines.append(dict(desc=it.get("desc", {"en": TX["en"]["materials"], "fr": TX["fr"]["materials"]}), qty=1, unit="", pu=amt, amt=amt))
        maths_parts.append(lambda L, cost=cost, mk=mk, amt=amt: f"{TX[L]['materials']} {money(cost, L)} × {num(1 + mk, L)} = {money(amt, L)}")
    else:
        q = it.get("qty", 1); pu = it["price"]
        lines.append(dict(desc=it["desc"], qty=q, unit=it.get("unit", ""), pu=pu, amt=q * pu))
trv = P.get("travel", 0)
if isinstance(trv, dict): trv = trv.get("km", 0) * trv.get("rate", 0) + trv.get("fixed", 0)
if trv:
    lines.append(dict(desc=P.get("travel_label", {"en": TX["en"]["travel"], "fr": TX["fr"]["travel"]}), qty=1, unit="", pu=trv, amt=trv))
    maths_parts.append(lambda L, trv=trv: f"{tr_(P.get('travel_label', TX[L]['travel']), L)} {money(trv, L)}")
sub = sum(l["amt"] for l in lines)
if P.get("discount"):
    d = P["discount"] if P["discount"] >= 1 else sub * P["discount"]
    lines.append(dict(desc={"en": TX["en"]["discount"], "fr": TX["fr"]["discount"]}, qty=1, unit="", pu=-d, amt=-d)); sub -= d
mn = P.get("min_total", 0)
if mn and sub < mn:
    lines.append(dict(desc={"en": TX["en"]["mintot"], "fr": TX["fr"]["mintot"]}, qty=1, unit="", pu=mn - sub, amt=mn - sub)); warn.append(f"raised to the minimum charge {mn}"); sub = mn
rt = P.get("round_to", 0)
if rt and rt > 0.01 and P.get("show") == "total": sub = math.ceil(sub / rt - 1e-9) * rt
sub = round(sub, 2)
floor = P.get("labour_floor")
if floor and labour_hours and labour_total / labour_hours < floor - 1e-6: warn.append(f"labour {labour_total / labour_hours:.2f}/h is below the floor {floor}/h")
reg = P.get("tax_registered", True); rate = P.get("tax_rate", 0.20 if C == "FR" else 0.10) if reg else 0
tax = round(sub * rate, 2); total = round(sub + tax, 2)
dep = J.get("deposit_pct", 0); dep_amt = round(total * dep, 2)
if C == "AU" and dep and total >= 7500 and dep > 0.065: warn.append("WA home building contracts of $7,500+: deposit capped at 6.5% — check before sending")
rp = P.get("range_pct", 0.15); rng = [total, round(total * (1 + rp), 2)]
if not CL.get("name") or "[" in CL.get("name", ""): to_check.append("client name")
if not CL.get("address"): to_check.append("client address")
maths = lambda L: " · ".join(f(L) for f in maths_parts) + (f" · {labels(L)['sub']} {money(sub, L)} + {labels(L)['tax']} {money(tax, L)} = {money(total, L)}" if reg else f" · {TX[L]['total_nt']} {money(sub, L)}")

# ---------- PDF ----------
today = datetime.date.fromisoformat(J.get("date", datetime.date.today().isoformat()))
valid = today + datetime.timedelta(days=J.get("validity_days", 30))
fmt = (lambda d: d.strftime("%m/%d/%Y")) if C == "US" else (lambda d: d.strftime("%d/%m/%Y"))
COLR = colors.HexColor(B.get("colour", "#13232B")); ACC = colors.HexColor(B.get("accent", "#FFC629"))
def ss(**k): return ParagraphStyle("x", fontName=k.pop("f", FN), fontSize=k.pop("s", 9), leading=k.pop("ld", 12), **k)

def build(L, internal):
    T = labels(L); co = T["colon"]
    last = (CL.get("name") or "client").replace("[", "").replace("]", "").split()[-1]
    base = J.get("file") or f"{'Devis' if L == 'fr' else 'Quote'}_{J.get('number', 'X')}_{last}"
    fname = base + ("_INTERNE" if L == "fr" else "_INTERNAL") if internal else base
    pdf = os.path.join(OUT, fname + ".pdf")
    s_small = ss(s=8, ld=10, textColor=colors.HexColor("#555555")); s_n = ss(); s_b = ss(f=FB); s_r = ss(alignment=TA_RIGHT)
    doc = SimpleDocTemplate(pdf, pagesize=letter if C in ("US", "CA") else A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=14 * mm, bottomMargin=16 * mm,
                            title=f"{T['quote']} {J.get('number', '')}")
    el = []
    left = [Paragraph(f"<b>{B['name']}</b>", ss(f=FB, s=13, ld=16, textColor=COLR))]
    for k in ("legal", "address", "phone", "email", "web"):
        if B.get(k): left.append(Paragraph(tr_(B[k], L), s_small))
    if B.get("id"): left.append(Paragraph(f"{B.get('id_label', 'SIRET' if C == 'FR' else 'ABN')} {B['id']}", s_small))
    logo = B.get("logo")
    if logo and os.path.exists(logo):
        lt = Table([[RLImage(logo, width=20 * mm, height=20 * mm, kind="proportional"), left]], colWidths=[24 * mm, 81 * mm])
        lt.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)])); left = [lt]
    right = [Paragraph(T["quote"], ss(f=FB, s=24, ld=28, textColor=COLR, alignment=TA_RIGHT)),
             Paragraph(f"{T['no']} <b>{J.get('number', '')}</b>", s_r), Paragraph(f"{T['date']}{co} {fmt(today)}", s_r), Paragraph(f"{T['valid']}{co} {fmt(valid)}", s_r)]
    head = Table([[left, right]], colWidths=[105 * mm, 73 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 0)]))
    el += [head, Spacer(1, 6 * mm)]
    cb = [Paragraph(f"<b>{T['client']}</b>", ss(f=FB, s=8, textColor=colors.HexColor("#777777"))), Paragraph(f"<b>{CL.get('name', '')}</b>", s_n)]
    if CL.get("address"): cb.append(Paragraph(CL["address"], s_n))
    if CL.get("id"): cb.append(Paragraph(CL["id"], s_small))
    info = []
    if J.get("title"): info.append(Paragraph(f"<b>{tr_(J['title'], L)}</b>", ss(f=FB, s=11, ld=14)))
    if J.get("start"): info.append(Paragraph(f"{T['start']}{co} {tr_(J['start'], L)}", s_n))
    if J.get("duration"): info.append(Paragraph(f"{T['duration']}{co} {tr_(J['duration'], L)}", s_n))
    box = Table([[cb, info]], colWidths=[89 * mm, 89 * mm])
    box.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, 0), colors.HexColor("#F3F5F6")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                             ("LEFTPADDING", (0, 0), (-1, -1), 8), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 8)]))
    el += [box, Spacer(1, 5 * mm)]
    scope = [tr_(s_, L) for s_ in J.get("scope", [])]
    hdr = lambda x, right=False: Paragraph(f"<b>{x}</b>", ss(f=FB, textColor=colors.white, alignment=(TA_RIGHT if right else 0)))
    if P.get("show") == "total" and not internal:
        rows = [[hdr(T["scope"]), ""]] + [[Paragraph("• " + s_, s_n), ""] for s_ in (scope or [tr_(l["desc"], L) for l in lines])]
        rows.append([Paragraph(f"<b>{T['sub'] if reg else T['total_nt']}</b>", s_b), Paragraph(f"<b>{money(sub, L)}</b>", s_r)])
        tbl = Table(rows, colWidths=[140 * mm, 38 * mm]); extra = [("SPAN", (0, 0), (1, 0))]
    else:
        if scope:
            el.append(Paragraph(f"<b>{T['scope']}</b>", s_b))
            for s_ in scope: el.append(Paragraph("• " + s_, s_n))
            el.append(Spacer(1, 3 * mm))
        rows = [[hdr(T["desc"])] + [hdr(x, True) for x in (T["qty"], T["unit"], T["pu"], T["amount"])]]
        for l in lines:
            rows.append([Paragraph(tr_(l["desc"], L), s_n), Paragraph(num(l["qty"], L), s_r), Paragraph(tr_(l["unit"], L) or "", s_r), Paragraph(money(l["pu"], L), s_r), Paragraph(money(l["amt"], L), s_r)])
        tbl = Table(rows, colWidths=[84 * mm, 16 * mm, 20 * mm, 28 * mm, 30 * mm], repeatRows=1); extra = []
    tbl.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), COLR), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                             ("LINEBELOW", (0, 1), (-1, -1), 0.4, colors.HexColor("#DDE3E5")), ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)] + extra))
    el += [tbl, Spacer(1, 4 * mm)]
    pct = lambda x: f"{x * 100:g} %" if L == "fr" else f"{x * 100:g}%"
    tot = [[T["sub"], money(sub, L)], [f"{T['tax']} {pct(rate)}", money(tax, L)], [T["total"], money(total, L)]] if reg else [[T["total_nt"], money(sub, L)]]
    if dep: tot += [[f"{T['deposit']} ({pct(dep)})", money(dep_amt, L)], [T["balance"], money(total - dep_amt, L)]]
    ti = 2 if reg else 0
    tt = Table([[Paragraph(f"<b>{a}</b>" if i == ti else a, s_n), Paragraph(f"<b>{b}</b>" if i == ti else b, s_r)] for i, (a, b) in enumerate(tot)], colWidths=[56 * mm, 34 * mm], hAlign="RIGHT")
    tt.setStyle(TableStyle([("BACKGROUND", (0, ti), (-1, ti), ACC), ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4), ("LINEABOVE", (0, ti), (-1, ti), 0.8, COLR)]))
    el.append(tt)
    if not reg: el.append(Paragraph(T["notax"], ss(s=8, alignment=TA_RIGHT)))
    el.append(Spacer(1, 5 * mm))
    foot = []
    if J.get("excluded"): foot.append(Paragraph(f"<b>{T['excluded']}</b>{co} " + " · ".join(tr_(x, L) for x in J["excluded"]), s_n))
    cond = [tr_(x, L) for x in J.get("notes", [])]
    for k in ("payment", "variation_clause", "warranty"):
        if J.get(k): cond.append(tr_(J[k], L))
    for k in ("insurance", "bank"):
        if B.get(k): cond.append(tr_(B[k], L))
    if cond:
        foot += [Spacer(1, 2 * mm), Paragraph(f"<b>{T['notes']}</b>", s_n)] + [Paragraph("• " + c, s_small) for c in cond]
    if internal:
        foot += [Spacer(1, 4 * mm), Paragraph(f"<b>{T['maths']}</b>{co} " + maths(L), ss(s=8, ld=11, textColor=colors.HexColor("#8A5A00")))]
    else:
        foot += [Spacer(1, 5 * mm), Paragraph(tr_(J.get("accept", T["accept"]), L), s_b), Spacer(1, 14 * mm)]
    el.append(KeepTogether(foot))
    stamp = T["internal"] if internal else (T["draft"] if J.get("draft") else None)
    def deco(c, d):
        c.saveState(); c.setFillColor(ACC); c.rect(0, d.pagesize[1] - 5 * mm, d.pagesize[0], 5 * mm, fill=1, stroke=0)
        c.setFont(FN, 7); c.setFillColor(colors.HexColor("#888888"))
        c.drawRightString(d.pagesize[0] - 16 * mm, 9 * mm, f"{B['name']} · {T['quote']} {J.get('number', '')} · {T['page']} {d.page}")
        if stamp:
            c.setFont(FB, 10); c.setFillColor(colors.HexColor("#C0392B")); c.drawString(16 * mm, 9 * mm, stamp)
        c.restoreState()
    doc.build(el, onFirstPage=deco, onLaterPages=deco)
    png = os.path.join(OUT, fname + "_preview")
    try: subprocess.run(["pdftoppm", "-png", "-r", "60", "-singlefile", pdf, png], check=True, capture_output=True); png += ".png"
    except Exception: png = None
    return {"pdf": pdf, "preview": png}

files = [build(L, J.get("internal", False) and i > 0) for i, L in enumerate(LANGS)]
L0 = LANGS[-1] if J.get("internal") else LANGS[0]
print(json.dumps({"files": files, "subtotal": sub, "tax": tax, "total": total, "deposit": dep_amt, "range_incl_tax": rng,
                  "maths": maths(L0), "warnings": warn, "to_check": to_check}, ensure_ascii=False, indent=1))

